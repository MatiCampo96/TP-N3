package TPN3.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HeladeriaElFrioApplicationTests {

	@Test
	void contextLoads() {
	}

}
