package TPN3.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HeladeriaElFrioApplication {

	public static void main(String[] args) {
		SpringApplication.run(HeladeriaElFrioApplication.class, args);
	}

}
