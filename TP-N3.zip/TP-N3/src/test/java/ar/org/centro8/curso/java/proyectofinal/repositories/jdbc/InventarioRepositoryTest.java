package ar.org.centro8.curso.java.proyectofinal.repositories.jdbc;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import ar.org.centro8.curso.java.proyectofinal.connector.Connector;
import ar.org.centro8.curso.java.proyectofinal.entities.Inventario;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_InventarioRepository;

public class InventarioRepositoryTest {

    I_InventarioRepository InventarioRepository = new InventarioRepository(Connector.getConnection());

    @Test
    void testSave() {
        Inventario Inventario1 = new Inventario("xxx", "xxx", "xxx", 1, 1, 1, 1, "0001-01-01");
        Inventario Inventario2 = new Inventario("xxx", "xxx", "xxx", 1, 1, 1, 1, "0001-01-01");
        InventarioRepository.save(Inventario1);
        InventarioRepository.save(Inventario2);

        assertEquals(Inventario1.getProd_id() > 0, true);
        assertEquals(Inventario1.getProd_id(), Inventario2.getProd_id() - 1);
    }

    @Test
    void testGetAll() {
        assertEquals(InventarioRepository.getAll().size() >= 2, true);
    }

    @Test
    void testRemove() {
        int cantidadInicial = InventarioRepository.getAll().size();
        InventarioRepository.remove(InventarioRepository.getAll().get(cantidadInicial - 1));
        int cantidadFinal = InventarioRepository.getAll().size();
        assertEquals(cantidadInicial, cantidadFinal + 1);
    }

    @Test
    void testUpdate() {
        int cantidad = InventarioRepository.getAll().size();
        Inventario Inventario = InventarioRepository.getAll().get(cantidad - 1);
        Inventario.setProd_nombre("ooo");
        Inventario.setProd_tipo("ooo");
        Inventario.setProd_desc("ooo");
        Inventario.setStock_units(1);
        Inventario.setStock_kg(1);
        Inventario.setPrecio_costo(1);
        Inventario.setSuc_id(1);
        Inventario.setFecha_ingreso("0001-01-01");
        InventarioRepository.update(Inventario);
        Inventario Inventario2 = InventarioRepository.getAll().get(cantidad - 1);

        assertEquals(Inventario.getProd_nombre(), Inventario2.getProd_nombre());
        assertEquals(Inventario.getProd_tipo(), Inventario2.getProd_tipo());
        assertEquals(Inventario.getProd_desc(), Inventario2.getProd_desc());
        assertEquals(Inventario.getStock_units(), Inventario2.getStock_units());
        assertEquals(Inventario.getStock_kg(), Inventario2.getStock_kg());
        assertEquals(Inventario.getPrecio_costo(), Inventario2.getPrecio_costo());
        assertEquals(Inventario.getSuc_id(), Inventario2.getSuc_id());
        assertEquals(Inventario.getFecha_ingreso(), Inventario2.getFecha_ingreso());

    }
}