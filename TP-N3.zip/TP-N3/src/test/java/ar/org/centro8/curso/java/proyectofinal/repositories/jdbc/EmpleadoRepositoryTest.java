package ar.org.centro8.curso.java.proyectofinal.repositories.jdbc;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import ar.org.centro8.curso.java.proyectofinal.connector.Connector;
import ar.org.centro8.curso.java.proyectofinal.entities.Empleado;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_EmpleadoRepository;

public class EmpleadoRepositoryTest {
    
    I_EmpleadoRepository EmpleadoRepository=new EmpleadoRepository(Connector.getConnection());

    @Test
    void testSave() {
        Empleado Empleado1=new Empleado("xxx", "xxx", 1, "xxx", 1, "0001-01.01");
        Empleado Empleado2=new Empleado("xxx", "xxx", 1, "xxx", 1, "0001-01.01");
        EmpleadoRepository.save(Empleado1);
        EmpleadoRepository.save(Empleado2);

        assertEquals(Empleado1.getEmp_id()>0, true);
        assertEquals(Empleado1.getEmp_id(), Empleado2.getEmp_id()-1);
    }

    @Test
    void testGetAll() {
        assertEquals(EmpleadoRepository.getAll().size()>=2, true);
    }

    @Test
    void testRemove() {
        int cantidadInicial=EmpleadoRepository.getAll().size();
        EmpleadoRepository.remove(EmpleadoRepository.getAll().get(cantidadInicial-1));
        int cantidadFinal=EmpleadoRepository.getAll().size();
        assertEquals(cantidadInicial, cantidadFinal+1);
    }

    @Test
    void testUpdate() {
        int cantidad=EmpleadoRepository.getAll().size();
        Empleado Empleado=EmpleadoRepository.getAll().get(cantidad-1);
        Empleado.setNombre("ooo");
        Empleado.setApellido("ooo");
        Empleado.setSuc_id(1);
        Empleado.setPuesto("ooo");
        Empleado.setSueldo(1);
        Empleado.setFecha_contratacion("0001-01-01");
        EmpleadoRepository.update(Empleado);
        Empleado Empleado2=EmpleadoRepository.getAll().get(cantidad-1);

        assertEquals(Empleado.getNombre(), Empleado2.getNombre());
        assertEquals(Empleado.getApellido(), Empleado2.getApellido());
        assertEquals(Empleado.getSuc_id(), Empleado2.getSuc_id());
        assertEquals(Empleado.getPuesto(), Empleado2.getPuesto());
        assertEquals(Empleado.getSueldo(), Empleado2.getSueldo());
        assertEquals(Empleado.getFecha_contratacion(), Empleado2.getFecha_contratacion());

    }
}
