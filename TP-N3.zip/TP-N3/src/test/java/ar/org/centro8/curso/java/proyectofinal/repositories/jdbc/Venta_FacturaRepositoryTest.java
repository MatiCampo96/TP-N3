package ar.org.centro8.curso.java.proyectofinal.repositories.jdbc;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import ar.org.centro8.curso.java.proyectofinal.connector.Connector;
import ar.org.centro8.curso.java.proyectofinal.entities.Venta_Factura;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_Venta_FacturaRepository;

public class Venta_FacturaRepositoryTest {

    I_Venta_FacturaRepository Venta_FacturaRepository = new Venta_FacturaRepository(Connector.getConnection());

    @Test
    void testSave() {
        Venta_Factura Venta_Factura1 = new Venta_Factura("0001-01-01 00:00:01", "xxx", 1);
        Venta_Factura Venta_Factura2 = new Venta_Factura("0001-01-01", "xxx", 1);
        Venta_FacturaRepository.save(Venta_Factura1);
        Venta_FacturaRepository.save(Venta_Factura2);

        assertEquals(Venta_Factura1.getOrd_num() > 0, true);
        assertEquals(Venta_Factura1.getOrd_num(), Venta_Factura2.getOrd_num() - 1);
    }

    @Test
    void testGetAll() {
        assertEquals(Venta_FacturaRepository.getAll().size() >= 2, true);
    }

    @Test
    void testRemove() {
        int cantidadInicial = Venta_FacturaRepository.getAll().size();
        Venta_FacturaRepository.remove(Venta_FacturaRepository.getAll().get(cantidadInicial - 1));
        int cantidadFinal = Venta_FacturaRepository.getAll().size();
        assertEquals(cantidadInicial, cantidadFinal + 1);
    }

    @Test
    void testUpdate() {
        int cantidad = Venta_FacturaRepository.getAll().size();
        Venta_Factura Venta_Factura = Venta_FacturaRepository.getAll().get(cantidad - 1);
        Venta_Factura.setFecha_y_hora("0001-01-01 00:00:01");
        Venta_Factura.setMedio_de_pago("ooo");
        Venta_Factura.setPrecio_total(1);
        Venta_FacturaRepository.update(Venta_Factura);
        Venta_Factura Venta_Factura2 = Venta_FacturaRepository.getAll().get(cantidad - 1);

        assertEquals(Venta_Factura.getFecha_y_hora(), Venta_Factura2.getFecha_y_hora());
        assertEquals(Venta_Factura.getMedio_de_pago(), Venta_Factura2.getMedio_de_pago());
        assertEquals(Venta_Factura.getPrecio_total(), Venta_Factura2.getPrecio_total());
    }
}
