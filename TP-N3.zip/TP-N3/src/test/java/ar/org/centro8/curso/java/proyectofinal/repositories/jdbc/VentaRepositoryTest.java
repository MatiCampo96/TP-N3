package ar.org.centro8.curso.java.proyectofinal.repositories.jdbc;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import ar.org.centro8.curso.java.proyectofinal.connector.Connector;
import ar.org.centro8.curso.java.proyectofinal.entities.Venta;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_VentaRepository;

public class VentaRepositoryTest {

    I_VentaRepository VentaRepository = new VentaRepository(Connector.getConnection());

    @Test
    void testSave() {
        int cantidadInicial = VentaRepository.getAll().size();
        Venta Venta1 = new Venta(2, 7, "xxx", "xxx", 1, 1, 1);
        Venta Venta2 = new Venta(2, 1, "xxx", "xxx", 1, 1, 1);
        VentaRepository.save(Venta1);
        VentaRepository.save(Venta2);
        int cantidadFinal = VentaRepository.getAll().size();

        assertEquals(Venta1.getOrd_num() > 0 && Venta1.getProd_id() > 0, true);
        assertEquals(Venta2.getOrd_num() > 0 && Venta2.getProd_id() > 0, true);
        assertEquals(cantidadInicial, cantidadFinal - 2);
    }

    @Test
    void testGetAll() {
        assertEquals(VentaRepository.getAll().size() >= 2, true);
    }

    @Test
    void testRemove() {
        int cantidadInicial = VentaRepository.getAll().size();
        VentaRepository.remove(VentaRepository.getAll().get(cantidadInicial - 1));
        int cantidadFinal = VentaRepository.getAll().size();
        assertEquals(cantidadInicial, cantidadFinal + 1);
    }

    @Test
    void testUpdate() {
        int cantidad = VentaRepository.getAll().size();
        Venta Venta = VentaRepository.getAll().get(cantidad - 1);
        Venta.setProd_presentacion("ooo");
        Venta.setCant_peso(1);
        Venta.setCant_units(1);
        Venta.setPrecio_unitario(1);
        VentaRepository.update(Venta);
        Venta Venta2 = VentaRepository.getAll().get(cantidad - 1);

        assertEquals(Venta.getProd_presentacion(), Venta2.getProd_presentacion());
        assertEquals(Venta.getCant_peso(), Venta2.getCant_peso());
        assertEquals(Venta.getCant_units(), Venta2.getCant_units());
        assertEquals(Venta.getPrecio_unitario(), Venta2.getPrecio_unitario());
    }
}
