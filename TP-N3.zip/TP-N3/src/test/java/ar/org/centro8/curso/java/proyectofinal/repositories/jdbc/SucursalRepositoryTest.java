package ar.org.centro8.curso.java.proyectofinal.repositories.jdbc;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import ar.org.centro8.curso.java.proyectofinal.connector.Connector;
import ar.org.centro8.curso.java.proyectofinal.entities.Sucursal;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_SucursalRepository;

public class SucursalRepositoryTest {
    
    I_SucursalRepository sucursalRepository=new SucursalRepository(Connector.getConnection());

    @Test
    void testSave() {
        Sucursal sucursal1=new Sucursal("xxx", "xxx", "xxx");
        Sucursal sucursal2=new Sucursal("xxx", "xxx", "xxx");
        sucursalRepository.save(sucursal1);
        sucursalRepository.save(sucursal2);

        assertEquals(sucursal1.getSuc_id()>0, true);
        assertEquals(sucursal1.getSuc_id(), sucursal2.getSuc_id()-1);
    }

    @Test
    void testGetAll() {
        assertEquals(sucursalRepository.getAll().size()>=2, true);
    }

    @Test
    void testRemove() {
        int cantidadInicial=sucursalRepository.getAll().size();
        sucursalRepository.remove(sucursalRepository.getAll().get(cantidadInicial-1));
        int cantidadFinal=sucursalRepository.getAll().size();
        assertEquals(cantidadInicial, cantidadFinal+1);
    }

    @Test
    void testUpdate() {
        int cantidad=sucursalRepository.getAll().size();
        Sucursal sucursal=sucursalRepository.getAll().get(cantidad-1);
        sucursal.setSuc_nombre("ooo");
        sucursal.setSuc_direccion("ooo");
        sucursal.setCiudad("ooo");
        sucursalRepository.update(sucursal);
        Sucursal sucursal2=sucursalRepository.getAll().get(cantidad-1);

        assertEquals(sucursal.getSuc_nombre(), sucursal2.getSuc_nombre());
        assertEquals(sucursal.getSuc_direccion(), sucursal2.getSuc_direccion());
        assertEquals(sucursal.getCiudad(), sucursal2.getCiudad());
    }
}
