package com.TPN3.TPN3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpN3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
