package ar.org.centro8.curso.java.proyectofinal.entities;

public class Venta {

    public Venta() {
    }

    public Venta(int prod_id, String prod_sabor, String prod_presentacion, float cant_peso, int cant_units,
            float precio_unitario) {
        this.prod_id = prod_id;
        this.prod_sabor = prod_sabor;
        this.prod_presentacion = prod_presentacion;
        this.cant_peso = cant_peso;
        this.cant_units = cant_units;
        this.precio_unitario = precio_unitario;
    }

    public Venta(int ord_num, int prod_id, String prod_sabor, String prod_presentacion, float cant_peso,
            int cant_units, float precio_unitario) {
        this.ord_num = ord_num;
        this.prod_id = prod_id;
        this.prod_sabor = prod_sabor;
        this.prod_presentacion = prod_presentacion;
        this.cant_peso = cant_peso;
        this.cant_units = cant_units;
        this.precio_unitario = precio_unitario;
    }

    private int ord_num;
    private int prod_id;
    private String prod_sabor;
    private String prod_presentacion;
    private float cant_peso;
    private int cant_units;
    private float precio_unitario;

    public int getOrd_num() {
        return ord_num;
    }

    public void setOrd_num(int ord_num) {
        this.ord_num = ord_num;
    }

    public int getProd_id() {
        return prod_id;
    }

    public void setProd_id(int prod_id) {
        this.prod_id = prod_id;
    }

    public String getProd_sabor() {
        return prod_sabor;
    }

    public void setProd_sabor(String prod_sabor) {
        this.prod_sabor = prod_sabor;
    }

    public String getProd_presentacion() {
        return prod_presentacion;
    }

    public void setProd_presentacion(String prod_presentacion) {
        this.prod_presentacion = prod_presentacion;
    }

    public float getCant_peso() {
        return cant_peso;
    }

    public void setCant_peso(float cant_peso) {
        this.cant_peso = cant_peso;
    }

    public int getCant_units() {
        return cant_units;
    }

    public void setCant_units(int cant_units) {
        this.cant_units = cant_units;
    }

    public float getPrecio_unitario() {
        return precio_unitario;
    }

    public void setPrecio_unitario(float precio_unitario) {
        this.precio_unitario = precio_unitario;
    }

    @Override
    public String toString() {
        return "Venta [ord_num=" + ord_num + ", prod_id=" + prod_id + ", prod_sabor=" + prod_sabor
                + ", prod_presentacion=" + prod_presentacion + ", cant_peso=" + cant_peso + ", cant_units=" + cant_units
                + ", precio_unitario=" + precio_unitario + "]";
    }

}
