package ar.org.centro8.curso.java.proyectofinal.repositories.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.proyectofinal.entities.Empleado;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_EmpleadoRepository;

public class EmpleadoRepository implements I_EmpleadoRepository {
    private Connection conn;

    public EmpleadoRepository(Connection conn) {
        this.conn = conn;
    }

    @Override
    public List<Empleado> getAll() {
        List<Empleado> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery(
                "select * from empleados")) {
            while (rs.next()) {
                list.add(new Empleado(
                        rs.getInt("emp_id"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getInt("suc_id"),
                        rs.getString("puesto"),
                        rs.getFloat("sueldo"),
                        rs.getString("fecha_contratacion")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    @Override
    public void save(Empleado empleado) {
        if (empleado == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into empleados (emp_id,nombre,apellido,suc_id,puesto,sueldo,fecha_contratacion) values (?,?,?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, empleado.getEmp_id());
            ps.setString(2, empleado.getNombre());
            ps.setString(3, empleado.getApellido());
            ps.setInt(4, empleado.getSuc_id());
            ps.setString(5, empleado.getPuesto());
            ps.setFloat(6, empleado.getSueldo());
            ps.setString(7, empleado.getFecha_contratacion());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                empleado.setEmp_id(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }

    }

    @Override
    public void remove(Empleado empleado) {
        if (empleado == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "delete from empleados where emp_id=?")) {
            ps.setInt(1, empleado.getEmp_id());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }

    }

    @Override
    public void update(Empleado empleado) {
        if (empleado == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "update empleados set emp_id=?, nombre=?, apellido=?, suc_id=?, puesto=?, sueldo=?, fecha_contratacion=? where emp_id=?")) {
            ps.setInt(1, empleado.getEmp_id());
            ps.setString(2, empleado.getNombre());
            ps.setString(3, empleado.getApellido());
            ps.setInt(4, empleado.getSuc_id());
            ps.setString(5, empleado.getPuesto());
            ps.setFloat(6, empleado.getSueldo());
            ps.setString(7, empleado.getFecha_contratacion());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }

    }

}
