package ar.org.centro8.curso.java.proyectofinal.entities;

public class Empleado {
    private int emp_id;
    private String nombre;
    private String apellido;
    private int suc_id;
    private String puesto;
    private float sueldo;
    private String fecha_contratacion;

    public Empleado() {
    };

    public Empleado(String nombre, String apellido, int suc_id, String puesto, float sueldo,
            String fecha_contratacion) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.suc_id = suc_id;
        this.puesto = puesto;
        this.sueldo = sueldo;
        this.fecha_contratacion = fecha_contratacion;
    }

    public Empleado(int emp_id, String nombre, String apellido, int suc_id, String puesto, float sueldo,
            String fecha_contratacion) {
        this.emp_id = emp_id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.suc_id = suc_id;
        this.puesto = puesto;
        this.sueldo = sueldo;
        this.fecha_contratacion = fecha_contratacion;
    }

    public int getEmp_id() {
        return emp_id;
    }

    public void setEmp_id(int emp_id) {
        this.emp_id = emp_id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getSuc_id() {
        return suc_id;
    }

    public void setSuc_id(int suc_id) {
        this.suc_id = suc_id;
    }

    public String getPuesto() {
        return puesto;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }

    public float getSueldo() {
        return sueldo;
    }

    public void setSueldo(float sueldo) {
        this.sueldo = sueldo;
    }

    public String getFecha_contratacion() {
        return fecha_contratacion;
    }

    public void setFecha_contratacion(String fecha_contratacion) {
        this.fecha_contratacion = fecha_contratacion;
    }

    @Override
    public String toString() {
        return "Empleado [emp_id=" + emp_id + ", nombre=" + nombre + ", apellido=" + apellido + ", suc_id=" + suc_id
                + ", puesto=" + puesto + ", sueldo=" + sueldo + ", fecha_contratacion=" + fecha_contratacion + "]";
    }
}
