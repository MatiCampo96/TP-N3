package ar.org.centro8.curso.java.proyectofinal.utils.sumar;

public class Sumar {
    public int sumar(int nro1, int nro2){
        return nro1+nro2;
    }
}
