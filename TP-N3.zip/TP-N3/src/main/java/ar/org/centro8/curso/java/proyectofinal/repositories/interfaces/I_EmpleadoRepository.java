package ar.org.centro8.curso.java.proyectofinal.repositories.interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import ar.org.centro8.curso.java.proyectofinal.entities.Empleado;
import ar.org.centro8.curso.java.proyectofinal.entities.Sucursal;

public interface I_EmpleadoRepository {
    void save(Empleado empleado);

    void remove(Empleado empleado);

    void update(Empleado empleado);

    List<Empleado> getAll();

    default Stream<Empleado> getStream() {
        return getAll().stream();
    }

    default Empleado getById(int emp_id) {
        return getAll()
                .stream()
                .filter(a -> a.getEmp_id() == emp_id)
                .findAny()
                .orElse(new Empleado());
    }

    default List<Empleado> getLikeNombre(String nombre) {
        if (nombre == null)
            return new ArrayList();
        return getAll()
                .stream()
                .filter(a -> a.getNombre() != null)
                .filter(a -> a
                        .getNombre()
                        .toLowerCase()
                        .contains(nombre.toLowerCase()))
                .toList();
    }

    default List<Empleado> getLikeApellido(String apellido) {
        if (apellido == null)
            return new ArrayList();
        return getAll()
                .stream()
                .filter(a -> a.getApellido() != null)
                .filter(a -> a
                        .getApellido()
                        .toLowerCase()
                        .contains(apellido.toLowerCase()))
                .toList();
    }

    default List<Empleado> getBySucursal(Sucursal sucursal) {
        if (sucursal == null)
            return new ArrayList<Empleado>();
        return getStream()
                .filter(a -> a.getSuc_id() == sucursal.getSuc_id())
                .collect(Collectors.toList());
    }

    default List<Empleado> getLikePuesto(String puesto) {
        if (puesto == null)
            return new ArrayList();
        return getAll()
                .stream()
                .filter(a -> a.getPuesto() != null)
                .filter(a -> a
                        .getPuesto()
                        .toLowerCase()
                        .contains(puesto.toLowerCase()))
                .toList();
    }

    default List<Empleado> getLikeFecha_de_contratacion(String fecha_de_contratacion) {
        if (fecha_de_contratacion == null)
            return new ArrayList();
        return getAll()
                .stream()
                .filter(a -> a.getFecha_contratacion() != null)
                .filter(a -> a
                        .getFecha_contratacion()
                        .toLowerCase()
                        .contains(fecha_de_contratacion.toLowerCase()))
                .toList();
    }
}
