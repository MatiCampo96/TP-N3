package ar.org.centro8.curso.java.proyectofinal.repositories.interfaces;

import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.proyectofinal.entities.Empleado;
import ar.org.centro8.curso.java.proyectofinal.entities.Sucursal;

public interface I_EmpleadoRepository {
    void save(Empleado empleado);

    void remove(Empleado empleado);

    void update(Empleado empleado);

    default Empleado getById(int emp_id) {
        return getAll()
                .stream()
                .filter(a -> a.getEmp_id() == emp_id)
                .findAny()
                .orElse(new Empleado());
    }

    List<Empleado> getAll();

    default List<Empleado> getLikeNombre(String nombre) {
        if (nombre == null)
            return new ArrayList();
        return getAll()
                .stream()
                .filter(a -> a.getNombre() != null)
                .filter(a -> a
                        .getNombre()
                        .toLowerCase()
                        .contains(nombre.toLowerCase()))
                .toList();
    }

    default List<Empleado> getLikeApellido(String apellido) {
        if (apellido == null)
            return new ArrayList();
        return getAll()
                .stream()
                .filter(a -> a.getApellido() != null)
                .filter(a -> a
                        .getApellido()
                        .toLowerCase()
                        .contains(apellido.toLowerCase()))
                .toList();
    }

    default List<Empleado> getLikeSucursal(Sucursal sucursal) {
        if (sucursal == null)
            return new ArrayList();
        return getAll()
                .stream()
                .filter(a -> a.getSuc_id() == sucursal.getSuc_id())
                .toList();
    }

    default List<Empleado> getLikePuesto(String puesto) {
        if (puesto == null)
            return new ArrayList();
        return getAll()
                .stream()
                .filter(a -> a.getPuesto() != null)
                .filter(a -> a
                        .getPuesto()
                        .toLowerCase()
                        .contains(puesto.toLowerCase()))
                .toList();
    }
}
