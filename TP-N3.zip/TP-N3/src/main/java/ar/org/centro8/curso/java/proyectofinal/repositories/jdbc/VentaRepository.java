package ar.org.centro8.curso.java.proyectofinal.repositories.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.proyectofinal.entities.Venta;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_VentaRepository;

public class VentaRepository implements I_VentaRepository {
    private Connection conn;

    public VentaRepository(Connection conn) {
        this.conn = conn;
    }

    @Override
    public List<Venta> getAll() {
        List<Venta> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery(
                "select * from ventas")) {
            while (rs.next()) {
                list.add(new Venta(
                        rs.getInt("ord_num"),
                        rs.getInt("prod_id"),
                        rs.getString("prod_sabor"),
                        rs.getString("prod_presentacion"),
                        rs.getFloat("cant_peso"),
                        rs.getInt("cant_units"),
                        rs.getFloat("precio_unitario")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    @Override
    public void save(Venta venta) {
        if (venta == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into ventas (ord_num,prod_id,prod_sabor,prod_presentacion,cant_peso,cant_units,precio_unitario) values (?,?,?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, venta.getOrd_num());
            ps.setInt(2, venta.getProd_id());
            ps.setString(3, venta.getProd_sabor());
            ps.setString(4, venta.getProd_presentacion());
            ps.setFloat(5, venta.getCant_peso());
            ps.setInt(6, venta.getCant_units());
            ps.setFloat(7, venta.getPrecio_unitario());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                venta.setOrd_num(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }

    }

    @Override
    public void remove(Venta venta) {
        if (venta == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "delete from ventas where ord_num=? && prod_id=?")) {
            ps.setInt(1, venta.getOrd_num());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void update(Venta venta) {
        if (venta == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "update ventas set prod_sabor=?, prod_presentacion=?, cant_peso=?, cant_units=?, precio_unitario=? where ord_num=? && prod_id=?")) {
            ps.setString(1, venta.getProd_sabor());
            ps.setString(2, venta.getProd_presentacion());
            ps.setFloat(3, venta.getCant_peso());
            ps.setInt(4, venta.getCant_units());
            ps.setFloat(5, venta.getPrecio_unitario());
            ps.setInt(6, venta.getOrd_num());
            ps.setInt(7, venta.getProd_id());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }

    }

}
