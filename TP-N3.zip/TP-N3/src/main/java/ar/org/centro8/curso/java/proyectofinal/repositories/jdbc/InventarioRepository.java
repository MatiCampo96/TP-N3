package ar.org.centro8.curso.java.proyectofinal.repositories.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.proyectofinal.entities.Inventario;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_InventarioRepository;

public class InventarioRepository implements I_InventarioRepository {
    private Connection conn;

    public InventarioRepository(Connection conn) {
        this.conn = conn;
    }

    @Override
    public List<Inventario> getAll() {
        List<Inventario> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery(
                "select * from inventario")) {
            while (rs.next()) {
                list.add(new Inventario(
                        rs.getInt("prod_id"),
                        rs.getString("prod_nombre"),
                        rs.getString("prod_tipo"),
                        rs.getString("prod_desc"),
                        rs.getInt("stock_units"),
                        rs.getFloat("stock_kg"),
                        rs.getFloat("precio_costo"),
                        rs.getInt("suc_id"),
                        rs.getString("fecha_ingreso")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    @Override
    public void save(Inventario inventario) {
        if (inventario == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into inventario (prod_id,prod_nombre,prod_tipo,prod_desc,stock_units,precio_costo,suc_id,fecha_ingreso) values (?,?,?,?,?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, inventario.getProd_id());
            ps.setString(2, inventario.getProd_nombre());
            ps.setString(3, inventario.getProd_tipo());
            ps.setString(4, inventario.getProd_desc());
            ps.setInt(5, inventario.getStock_units());
            ps.setFloat(6, inventario.getStock_kg());
            ps.setFloat(7, inventario.getPrecio_costo());
            ps.setInt(8, inventario.getSuc_id());
            ps.setString(9, inventario.getFecha_ingreso());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                inventario.setProd_id(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }

    }

    @Override
    public void remove(Inventario inventario) {
        if (inventario == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "delete from inventario where prod_id=?")) {
            ps.setInt(1, inventario.getProd_id());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }

    }

    @Override
    public void update(Inventario inventario) {
        if (inventario == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "update inventario set prod_id=?, prod_nombre=?, prod_tipo=?, prod_desc=?, stock_units=?, precio_costo=?, suc_id=?, fecha_ingreso=? values where prod_id=?")) {
            ps.setInt(1, inventario.getProd_id());
            ps.setString(2, inventario.getProd_nombre());
            ps.setString(3, inventario.getProd_tipo());
            ps.setString(4, inventario.getProd_desc());
            ps.setInt(5, inventario.getStock_units());
            ps.setFloat(6, inventario.getStock_kg());
            ps.setFloat(7, inventario.getPrecio_costo());
            ps.setInt(8, inventario.getSuc_id());
            ps.setString(9, inventario.getFecha_ingreso());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }

    }

}
