package ar.org.centro8.curso.java.proyectofinal.entities;

public class Sucursales {
    private int suc_id;
    private String suc_nombre;
    private String suc_direccion;
    private String ciudad;

    public Sucursales() {
    }

    public Sucursales(String suc_nombre, String suc_direccion, String ciudad) {
        this.suc_nombre = suc_nombre;
        this.suc_direccion = suc_direccion;
        this.ciudad = ciudad;
    }

    public Sucursales(int suc_id, String suc_nombre, String suc_direccion, String ciudad) {
        this.suc_id = suc_id;
        this.suc_nombre = suc_nombre;
        this.suc_direccion = suc_direccion;
        this.ciudad = ciudad;
    }

    public int getSuc_id() {
        return suc_id;
    }

    public void setSuc_id(int suc_id) {
        this.suc_id = suc_id;
    }

    public String getSuc_nombre() {
        return suc_nombre;
    }

    public void setSuc_nombre(String suc_nombre) {
        this.suc_nombre = suc_nombre;
    }

    public String getSuc_direccion() {
        return suc_direccion;
    }

    public void setSuc_direccion(String suc_direccion) {
        this.suc_direccion = suc_direccion;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    @Override
    public String toString() {
        return "Empleados [suc_id=" + suc_id + ", suc_nombre=" + suc_nombre + ", suc_direccion=" + suc_direccion
                + ", ciudad=" + ciudad + "]";
    }
}
