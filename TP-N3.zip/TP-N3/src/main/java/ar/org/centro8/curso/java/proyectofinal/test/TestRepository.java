package ar.org.centro8.curso.java.proyectofinal.test;

import java.sql.Connection;

import org.springframework.http.converter.xml.SourceHttpMessageConverter;

import ar.org.centro8.curso.java.proyectofinal.connector.Connector;
import ar.org.centro8.curso.java.proyectofinal.entities.*;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.*;
import ar.org.centro8.curso.java.proyectofinal.repositories.jdbc.*;

public class TestRepository {
    public static void main(String[] args) {
        Connection conn = Connector.getConnection();

        // TEST A EMPLEADOS
        I_EmpleadoRepository empleadoRepository = new EmpleadoRepository(conn);
        Empleado empleado = new Empleado("Lucas", "Torres", 4, "aprendiz", 20000, "2022-01-01");
        empleadoRepository.save(empleado);
        System.out.println(empleado);

        empleadoRepository.remove(empleadoRepository.getById(3));

        empleado = empleadoRepository.getById(6);
        if (empleado != null && empleado.getEmp_id() != 0) {
            empleado.setNombre("Javier");
            empleado.setApellido("Rivero");
            empleadoRepository.update(empleado);
        }

        System.out.println("**************************************");
        empleadoRepository.getAll().forEach(System.out::println);

        System.out.println("**************************************");
        empleadoRepository
                .getLikeNombre("mar")
                .forEach(System.out::println);
        System.out.println("**************************************");
        empleadoRepository
                .getLikeApellido("ko")
                .forEach(System.out::println);

        System.out.println("**************************************");
        // TEST A SUCURSALES
        I_SucursalRepository sucursalRepository = new SucursalRepository(conn);
        Sucursal sucursal = new Sucursal("El frio Jujuy", "Belgrano 1042", "Tilcara");
        sucursalRepository.save(sucursal);
        System.out.println(sucursal);

        sucursal = sucursalRepository.getById(4);
        if (sucursal != null) {
            sucursal.setCiudad("La Quiaca");
            sucursalRepository.update(sucursal);
        }

        System.out.println("**************************************");
        sucursalRepository.getAll().forEach(System.out::println);
        System.out.println("**************************************");
        sucursalRepository
                .getLikeCiudad("Mor")
                .forEach(System.out::println);

        System.out.println("**************************************");
        // TEST A VENTA_FACTURA
        I_Venta_FacturaRepository venta_facturaRepository = new Venta_FacturaRepository(conn);
        Venta_Factura venta_factura = new Venta_Factura("2022-01-22 14:24:45", "debito", 800);
        venta_facturaRepository.save(venta_factura);
        System.out.println(venta_factura);
        System.out.println("**************************************");
        venta_facturaRepository.getAll().forEach(System.out::println);
        System.out.println("**************************************");
        venta_facturaRepository
                .getLikeMedio_de_pago("credito")
                .forEach(System.out::println);

    }

}
