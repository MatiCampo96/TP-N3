package ar.org.centro8.curso.java.proyectofinal.test;

import java.sql.Connection;

import ar.org.centro8.curso.java.proyectofinal.connector.Connector;
import ar.org.centro8.curso.java.proyectofinal.entities.*;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.*;
import ar.org.centro8.curso.java.proyectofinal.repositories.jdbc.*;

public class TestRepository {
    public static void main(String[] args) {
        Connection conn = Connector.getConnection();
        I_EmpleadoRepository empleadoRepository = new EmpleadoRepository(conn);
        Empleado empleado = new Empleado("Lucas", "Torres", 4, "aprendiz", 20000, "2022-01-01");
        empleadoRepository.save(empleado);
        System.out.println(empleado);

        // empleado=empleadoRepository.getById(2);
        // empleadoRepository.remove(empleado);
        empleadoRepository.remove(empleadoRepository.getById(3));

        empleado = empleadoRepository.getById(5);
        if (empleado != null && empleado.getEmp_id() != 0) {
            empleado.setNombre("Javier");
            empleado.setApellido("River");
            empleadoRepository.update(empleado);
        }

        System.out.println("**************************************");
        empleadoRepository.getAll().forEach(System.out::println);

        System.out.println("**************************************");
        empleadoRepository
                .getLikeNombre("Jav")
                .forEach(System.out::println);
        System.out.println("**************************************");
        empleadoRepository
                .getLikeApellido("Ri")
                .forEach(System.out::println);

        System.out.println("**************************************");
        I_SucursalRepository sucursalRepository = new SucursalRepository(conn);
        Sucursal sucursal = new Sucursal("El frio Jujuy", "Belgrano 1042", "Tilcara");
        sucursalRepository.save(sucursal);
        System.out.println(sucursal);

        sucursalRepository.remove(sucursalRepository.getById(2));

        sucursal = sucursalRepository.getById(4);
        if (sucursal != null) {
            sucursal.setCiudad("La Quiaca");
            sucursalRepository.update(sucursal);
        }

        System.out.println("**************************************");
        sucursalRepository.getAll().forEach(System.out::println);
        System.out.println("**************************************");
        sucursalRepository
                .getLikeCiudad("Mor")
                .forEach(System.out::println);

    }
}
