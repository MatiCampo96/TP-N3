package ar.org.centro8.curso.java.proyectofinal.repositories.interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import ar.org.centro8.curso.java.proyectofinal.entities.Sucursal;

public interface I_SucursalRepository {
    void save(Sucursal sucursal);
    void remove(Sucursal sucursal);
    void update(Sucursal Sucursal);

    List<Sucursal>getAll();

    default Stream<Sucursal> getStream(){
        return getAll().stream();
    }
    default Sucursal getById(int suc_id){
        return getAll()
            .stream()
            .filter(a->a.getSuc_id()==suc_id)
            .findAny()
            .orElse(new Sucursal());        
    }
    default List<Sucursal>getLikeSuc_nombre(String suc_nombre){
        if(suc_nombre==null) return new ArrayList();
        return getAll()
            .stream()
            .filter(a->a.getSuc_nombre()!=null)
            .filter(a->a
                        .getSuc_nombre()
                        .toLowerCase()
                        .contains(suc_nombre.toLowerCase()))
            .toList();
    }

    default List<Sucursal>getLikeSuc_direccion(String suc_direccion){
        if(suc_direccion==null) return new ArrayList();
        return getAll()
            .stream()
            .filter(a->a.getSuc_direccion()!=null)
            .filter(a->a
                        .getSuc_direccion()
                        .toLowerCase()
                        .contains(suc_direccion.toLowerCase()))
            .toList();
        }

    default List<Sucursal>getLikeCiudad(String ciudad){
        if(ciudad==null) return new ArrayList();
        return getAll()
            .stream()
            .filter(a->a.getCiudad()!=null)
            .filter(a->a
                        .getCiudad()
                        .toLowerCase()
                        .contains(ciudad.toLowerCase()))
            .toList();
}
}
