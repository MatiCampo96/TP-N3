package ar.org.centro8.curso.java.proyectofinal.repositories.interfaces;

import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.proyectofinal.entities.Sucursal;

public interface I_SucursalRepository {
    void save(Sucursal sucursal);
    void remove(Sucursal sucursal);
    void update(Sucursal Sucursal);
    default Sucursal getById(int suc_id){
        return getAll()
            .stream()
            .filter(a->a.getSuc_id()==suc_id)
            .findAny()
            .orElse(new Sucursal());        
    }
    List<Sucursal>getAll();
    default List<Sucursal>getLikeSuc_nombre(String suc_nombre){
        if(suc_nombre==null) return new ArrayList();
        return getAll()
            .stream()
            .filter(a->a.getSuc_nombre()!=null)
            .filter(a->a
                        .getSuc_nombre()
                        .toLowerCase()
                        .contains(suc_nombre.toLowerCase()))
            .toList();
    }
    
}
