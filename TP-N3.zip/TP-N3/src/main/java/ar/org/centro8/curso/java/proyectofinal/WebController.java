package ar.org.centro8.curso.java.proyectofinal;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.centro8.curso.java.proyectofinal.connector.Connector;
import ar.org.centro8.curso.java.proyectofinal.entities.Empleado;
import ar.org.centro8.curso.java.proyectofinal.entities.Sucursal;
import ar.org.centro8.curso.java.proyectofinal.entities.Inventario;
import ar.org.centro8.curso.java.proyectofinal.entities.Venta;
import ar.org.centro8.curso.java.proyectofinal.entities.Venta_Factura;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_EmpleadoRepository;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_SucursalRepository;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_InventarioRepository;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_VentaRepository;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_Venta_FacturaRepository;
import ar.org.centro8.curso.java.proyectofinal.repositories.jdbc.EmpleadoRepository;
import ar.org.centro8.curso.java.proyectofinal.repositories.jdbc.SucursalRepository;
import ar.org.centro8.curso.java.proyectofinal.repositories.jdbc.InventarioRepository;
import ar.org.centro8.curso.java.proyectofinal.repositories.jdbc.VentaRepository;
import ar.org.centro8.curso.java.proyectofinal.repositories.jdbc.Venta_FacturaRepository;
//import jakarta.servlet.jsp.tagext.TryCatchFinally;

@Controller
public class WebController {

    private String mensajeSucursal = "Ingrese una nueva sucursal!";
    private String mensajeEmpleado = "Ingrese un nuevo empleado!";
    private String mensajeInventario = "Ingrese un nuevo articulo al inventario!";
    private String mensajeVenta = "Ingrese una nueva venta!";
    private String mensajeVenta_Factura = "Ingrese una nueva factura!";

    private I_SucursalRepository sucursalRepository = new SucursalRepository(Connector.getConnection());
    private I_EmpleadoRepository empleadoRepository = new EmpleadoRepository(Connector.getConnection());
    private I_InventarioRepository inventarioRepository = new InventarioRepository(Connector.getConnection());
    private I_VentaRepository ventaRepository = new VentaRepository(Connector.getConnection());
    private I_Venta_FacturaRepository venta_facturaRepository = new Venta_FacturaRepository(Connector.getConnection());

    @GetMapping("/")
    public String webMain() {
        return "index";
    }

    @GetMapping("/sucursales")
    public String getWebSucursales(
            @RequestParam(name = "buscarSuc_nombre", required = false, defaultValue = "") String buscarSuc_nombre,
            Model model) {
        model.addAttribute("sucursal", new Sucursal());
        model.addAttribute("mensajeSucursales", mensajeSucursal);
        model.addAttribute("all", sucursalRepository.getAll());
        model.addAttribute("likeSuc_nombre", sucursalRepository.getLikeSuc_nombre(buscarSuc_nombre));
        return "sucursales";
    }

    @GetMapping("/empleados")
    public String getWebEmpleados(
            @RequestParam(name = "buscarNombre", required = false, defaultValue = "") String buscarNombre,
            Model model) {
        model.addAttribute("Empleado", new Empleado());
        model.addAttribute("mensajeEmpleados", mensajeEmpleado);
        model.addAttribute("sucursal", sucursalRepository.getAll());
        model.addAttribute("likeNombre", empleadoRepository.getLikeNombre(buscarNombre));
        return "empleados";
    }

    // @GetMapping("/inventario")
    // public String getWebInventario(
    // @RequestParam(name="buscarApellido", required = false, defaultValue = "")
    // String buscarApellido,
    // Model model){
    // model.addAttribute("Empleado", new Empleado());
    // model.addAttribute("mensajeEmpleados", mensajeEmpleados);
    // model.addAttribute("cursos", cursoRepository.getAll());
    // model.addAttribute("likeApellido",
    // EmpleadoRepository.getLikeApellido(buscarApellido));
    // return "inventario";
    // }

    // @GetMapping("/ventas")
    // public String getWebVentas(
    // @RequestParam(name="buscarApellido", required = false, defaultValue = "")
    // String buscarApellido,
    // Model model){
    // model.addAttribute("Empleado", new Empleado());
    // model.addAttribute("mensajeEmpleados", mensajeEmpleados);
    // model.addAttribute("cursos", cursoRepository.getAll());
    // model.addAttribute("likeApellido",
    // EmpleadoRepository.getLikeApellido(buscarApellido));
    // return "ventas";
    // }

    // @GetMapping("/facturas")
    // public String getWebFacturas(
    // @RequestParam(name="buscarApellido", required = false, defaultValue = "")
    // String buscarApellido,
    // Model model){
    // model.addAttribute("Empleado", new Empleado());
    // model.addAttribute("mensajeEmpleados", mensajeEmpleados);
    // model.addAttribute("cursos", cursoRepository.getAll());
    // model.addAttribute("likeApellido",
    // EmpleadoRepository.getLikeApellido(buscarApellido));
    // return "facturas";
    // }

    @PostMapping("/savesucursal")
    public String saveCurso(@ModelAttribute Sucursal sucursal) {
        // System.out.println("*************************************************************************");
        // System.out.println(sucursal);
        // System.out.println("*************************************************************************");
        try {
            sucursalRepository.save(sucursal);
            mensajeSucursal = "Se ingreso un nuevo curso id: " + sucursal.getSuc_id();
        } catch (Exception e) {
            mensajeSucursal = "Ocurrio un error!";
        }
        return "redirect:sucursales";
    }

    @PostMapping("/saveempleado")
    public String saveEmpleado(@ModelAttribute Empleado empleado) {
        System.out.println("*************************************************************************");
        System.out.println(empleado);
        System.out.println("*************************************************************************");

        try {
            empleadoRepository.save(empleado);
            mensajeEmpleado = "Se ingreso un nuevo Empleado id: " + empleado.getEmp_id();
        } catch (Exception e) {
            mensajeEmpleado = "Ocurrio un error!";
        }
        return "redirect:empleados";
    }

    @PostMapping("/saveInventario")
    public String saveInventario(@ModelAttribute Inventario inventario) {
        System.out.println("*************************************************************************");
        System.out.println(inventario);
        System.out.println("*************************************************************************");

        try {
            inventarioRepository.save(inventario);
            mensajeInventario = "Se ingreso un nuevo articulo de inventario id: " + inventario.getProd_id();
        } catch (Exception e) {
            mensajeInventario = "Ocurrio un error!";
        }
        return "redirect:inventario";
    }

    @PostMapping("/saveVentas")
    public String saveVenta(@ModelAttribute Venta venta) {
        System.out.println("*************************************************************************");
        System.out.println(venta);
        System.out.println("*************************************************************************");

        try {
            ventaRepository.save(venta);
            mensajeVenta = "Se ingreso una nueva venta id: " + venta.getProd_id() + " " + venta.getOrd_num();
        } catch (Exception e) {
            mensajeVenta = "Ocurrio un error!";
        }
        return "redirect:ventas";
    }

    @PostMapping("/saveVenta_Factura")
    public String saveVenta_Factura(@ModelAttribute Venta_Factura venta_factura) {
        System.out.println("*************************************************************************");
        System.out.println(venta_factura);
        System.out.println("*************************************************************************");

        try {
            venta_facturaRepository.save(venta_factura);
            mensajeVenta_Factura = "Se ingreso una nueva factura orden numero: " + venta_factura.getOrd_num();
        } catch (Exception e) {
            mensajeVenta_Factura = "Ocurrio un error!";
        }
        return "redirect:facturas";
    }
}
// VER FACTURA ERRORES ETC TODO!