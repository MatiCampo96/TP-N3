package ar.org.centro8.curso.java.proyectofinal;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.centro8.curso.java.proyectofinal.connector.Connector;
import ar.org.centro8.curso.java.proyectofinal.entities.Empleado;
import ar.org.centro8.curso.java.proyectofinal.entities.Sucursal;
import ar.org.centro8.curso.java.proyectofinal.entities.Inventario;
import ar.org.centro8.curso.java.proyectofinal.entities.Venta;
import ar.org.centro8.curso.java.proyectofinal.entities.Venta_Factura;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_EmpleadoRepository;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_SucursalRepository;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_InventarioRepository;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_VentaRepository;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_Venta_FacturaRepository;
import ar.org.centro8.curso.java.proyectofinal.repositories.jdbc.EmpleadoRepository;
import ar.org.centro8.curso.java.proyectofinal.repositories.jdbc.SucursalRepository;
import ar.org.centro8.curso.java.proyectofinal.repositories.jdbc.InventarioRepository;
import ar.org.centro8.curso.java.proyectofinal.repositories.jdbc.VentaRepository;
import ar.org.centro8.curso.java.proyectofinal.repositories.jdbc.Venta_FacturaRepository;
import jakarta.servlet.jsp.tagext.TryCatchFinally;

@Controller
public class WebController {

    private String mensajeSucursal = "Ingrese una nueva sucursal!";
    private String mensajeEmpleado = "Ingrese un nuevo empleado!";
    private String mensajeInventario = "Ingrese un nuevo articulo al inventario!";
    private String mensajeVenta = "Ingrese una nueva venta!";
    private String mensajeVenta_Factura = "Ingrese una nueva factura!";

    private I_SucursalRepository sucursalRepository = new SucursalRepository(Connector.getConnection());
    private I_EmpleadoRepository empleadoRepository = new EmpleadoRepository(Connector.getConnection());
    private I_InventarioRepository inventarioRepository = new InventarioRepository(Connector.getConnection());
    private I_VentaRepository ventaRepository = new VentaRepository(Connector.getConnection());
    private I_Venta_FacturaRepository venta_facturaRepository = new Venta_FacturaRepository(Connector.getConnection());

    @GetMapping("/")
    public String webMain() {
        return "index";
    }

    @GetMapping("/sucursales")
    public String getWebSucursales(
            @RequestParam(name = "buscarSuc_nombre", required = false, defaultValue = "") String buscarSuc_nombre,
            Model model) {
        model.addAttribute("sucursal", new Sucursal());
        model.addAttribute("mensajeSucursales", mensajeSucursal);
        model.addAttribute("all", sucursalRepository.getAll());
        model.addAttribute("likeSuc_nombre", sucursalRepository.getLikeSuc_nombre(buscarSuc_nombre));
        return "sucursales";
    }

    @GetMapping("/empleados")
    public String getWebEmpleados(
            @RequestParam(name = "buscarNombre", required = false, defaultValue = "") String buscarNombre,
            Model model) {
        model.addAttribute("empleado", new Empleado());
        model.addAttribute("mensajeEmpleados", mensajeEmpleado);
        model.addAttribute("sucursal", sucursalRepository.getAll());
        model.addAttribute("likeNombre", empleadoRepository.getLikeNombre(buscarNombre));
        return "empleados";
    }

    @GetMapping("/inventario")
    public String getWebInventario(
    @RequestParam(name="buscarProd_nombre", required = false, defaultValue = "") String buscarProd_nombre,
    Model model){
    model.addAttribute("inventario", new Inventario());
    model.addAttribute("mensajeInventario", mensajeInventario);
    model.addAttribute("sucursal", sucursalRepository.getAll());
    model.addAttribute("likeProd_nombre",
    inventarioRepository.getLikeProd_nombre(buscarProd_nombre));
    return "inventario";
    }

    @GetMapping("/ventas")
    public String getWebVentas(
    @RequestParam(name="buscarProd_sabor", required = false, defaultValue = "")
    String buscarProd_sabor,
    Model model){
    model.addAttribute("venta", new Venta());
    model.addAttribute("mensajeVentas", mensajeVenta);
    model.addAttribute("venta_factura", venta_facturaRepository.getAll());
    model.addAttribute("inventario", inventarioRepository.getAll());
    model.addAttribute("likeProd_sabor",
    ventaRepository.getLikeProd_sabor(buscarProd_sabor));
    return "ventas";
    }

    @GetMapping("/facturas")
    public String getWebFacturas(
            @RequestParam(name = "buscarMedio_de_pago", required = false, defaultValue = "") String buscarMedio_de_pago,
            Model model) {
        model.addAttribute("venta_factura", new Venta_Factura());
        model.addAttribute("mensajeVenta_facturas", mensajeVenta_Factura);
        model.addAttribute("all", venta_facturaRepository.getAll());
        model.addAttribute("likeMedio_de_pago", venta_facturaRepository.getLikeMedio_de_pago(buscarMedio_de_pago));
        return "facturas";
    }

    @PostMapping("/savesucursal")
    public String saveCurso(@ModelAttribute Sucursal sucursal) {
        try {
            sucursalRepository.save(sucursal);
            mensajeSucursal = "Se ingreso una nueva sucursal id: " + sucursal.getSuc_id();
        } catch (Exception e) {
            mensajeSucursal = "Ocurrio un error!";
        }
        return "redirect:sucursales";
    }

    @PostMapping("/saveempleado")
    public String saveEmpleado(@ModelAttribute Empleado empleado) {
        try {
            empleadoRepository.save(empleado);
            mensajeEmpleado = "Se ingreso un nuevo Empleado id: " + empleado.getEmp_id();
        } catch (Exception e) {
            mensajeEmpleado = "Ocurrio un error!";
        }
        return "redirect:empleados";
    }

    @PostMapping("/saveinventario")
    public String saveInventario(@ModelAttribute Inventario inventario) {
        try {
            inventarioRepository.save(inventario);
            mensajeInventario = "Se ingreso un nuevo articulo de inventario id: " + inventario.getProd_id();
        } catch (Exception e) {
            mensajeInventario = "Ocurrio un error!";
        }
        return "redirect:inventario";
    }

    @PostMapping("/saveventa")
    public String saveVenta(@ModelAttribute Venta venta) {
        try {
            ventaRepository.save(venta);
            mensajeVenta = "Se ingreso una nueva venta id: " + venta.getProd_id() + " " + venta.getOrd_num();
        } catch (Exception e) {
            mensajeVenta = "Ocurrio un error!";
        }
        return "redirect:ventas";
    }

    @PostMapping("/saveventa_factura")
    public String saveVenta_Factura(@ModelAttribute Venta_Factura venta_factura) {
        try {
            venta_facturaRepository.save(venta_factura);
            mensajeVenta_Factura = "Se ingreso una nueva factura orden numero: " + venta_factura.getOrd_num();
        } catch (Exception e) {
            mensajeVenta_Factura = "Ocurrio un error!";
        }
        return "redirect:facturas";
    }
}
// VER FACTURA ERRORES ETC TODO!