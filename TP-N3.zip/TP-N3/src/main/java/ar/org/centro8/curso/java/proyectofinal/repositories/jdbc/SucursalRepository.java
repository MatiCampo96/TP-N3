package ar.org.centro8.curso.java.proyectofinal.repositories.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.proyectofinal.entities.Sucursal;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_SucursalRepository;

public class SucursalRepository implements I_SucursalRepository {
    private Connection conn;

    public SucursalRepository(Connection conn) {
        this.conn = conn;
    }

    @Override
    public List<Sucursal> getAll() {
        List<Sucursal> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery(
                "select * from sucursales")) {
            while (rs.next()) {
                list.add(new Sucursal(
                        rs.getInt("suc_id"),
                        rs.getString("suc_nombre"),
                        rs.getString("suc_direccion"),
                        rs.getString("ciudad")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    @Override
    public void save(Sucursal sucursal) {
        if (sucursal == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into sucursales (suc_id,suc_nombre,suc_direccion,ciudad) values (?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, sucursal.getSuc_id());
            ps.setString(2, sucursal.getSuc_nombre());
            ps.setString(3, sucursal.getSuc_direccion());
            ps.setString(4, sucursal.getCiudad());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                sucursal.setSuc_id(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }

    }

    @Override
    public void remove(Sucursal sucursal) {
        if (sucursal == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "delete from sucursales where suc_id=?")) {
            ps.setInt(1, sucursal.getSuc_id());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }

    }

    @Override
    public void update(Sucursal sucursal) {
        if (sucursal == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "update sucursales set suc_id=?, suc_nombre=?, suc_direccion=?, ciudad=? where suc_id=?")) {
            ps.setInt(1, sucursal.getSuc_id());
            ps.setString(2, sucursal.getSuc_nombre());
            ps.setString(3, sucursal.getSuc_direccion());
            ps.setString(4, sucursal.getCiudad());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }

    }

}