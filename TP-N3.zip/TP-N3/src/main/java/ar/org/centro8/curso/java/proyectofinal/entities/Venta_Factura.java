package ar.org.centro8.curso.java.proyectofinal.entities;

public class Venta_Factura {
    private String fecha_y_hora;
    private int ord_num;
    private String medio_de_pago;
    private float precio_total;

    public Venta_Factura() {
    }

    public Venta_Factura(String fecha_y_hora, String medio_de_pago, float precio_total) {
        this.fecha_y_hora = fecha_y_hora;
        this.medio_de_pago = medio_de_pago;
        this.precio_total = precio_total;
    }

    public Venta_Factura(String fecha_y_hora, int ord_num, String medio_de_pago, float precio_total) {
        this.fecha_y_hora = fecha_y_hora;
        this.ord_num = ord_num;
        this.medio_de_pago = medio_de_pago;
        this.precio_total = precio_total;
    }

    public String getFecha_y_hora() {
        return fecha_y_hora;
    }

    public void setFecha_y_hora(String fecha_y_hora) {
        this.fecha_y_hora = fecha_y_hora;
    }

    public int getOrd_num() {
        return ord_num;
    }

    public void setOrd_num(int ord_num) {
        this.ord_num = ord_num;
    }

    public String getMedio_de_pago() {
        return medio_de_pago;
    }

    public void setMedio_de_pago(String medio_de_pago) {
        this.medio_de_pago = medio_de_pago;
    }

    public float getPrecio_total() {
        return precio_total;
    }

    public void setPrecio_total(float precio_total) {
        this.precio_total = precio_total;
    }

    @Override
    public String toString() {
        return "Venta_Factura [fecha_y_hora=" + fecha_y_hora + ", ord_num=" + ord_num + ", medio_de_pago="
                + medio_de_pago + ", precio_total=" + precio_total + "]";
    }
}
