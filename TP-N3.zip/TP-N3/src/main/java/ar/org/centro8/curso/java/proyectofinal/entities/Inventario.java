package ar.org.centro8.curso.java.proyectofinal.entities;

public class Inventario {
    private int prod_id;
    private String prod_nombre;
    private String prod_tipo;
    private String prod_desc;
    private int stock_units;
    private float stock_kg;
    private float precio_costo;
    private int suc_id;
    private String fecha_ingreso;

    public Inventario() {
    }

    public Inventario(String prod_nombre, String prod_tipo, String prod_desc, int stock_units, float stock_kg,
            float precio_costo, int suc_id, String fecha_ingreso) {
        this.prod_nombre = prod_nombre;
        this.prod_tipo = prod_tipo;
        this.prod_desc = prod_desc;
        this.stock_units = stock_units;
        this.stock_kg = stock_kg;
        this.precio_costo = precio_costo;
        this.suc_id = suc_id;
        this.fecha_ingreso = fecha_ingreso;
    }

    public Inventario(int prod_id, String prod_nombre, String prod_tipo, String prod_desc, int stock_units,
            float stock_kg, float precio_costo, int suc_id, String fecha_ingreso) {
        this.prod_id = prod_id;
        this.prod_nombre = prod_nombre;
        this.prod_tipo = prod_tipo;
        this.prod_desc = prod_desc;
        this.stock_units = stock_units;
        this.stock_kg = stock_kg;
        this.precio_costo = precio_costo;
        this.suc_id = suc_id;
        this.fecha_ingreso = fecha_ingreso;
    }

    public int getProd_id() {
        return prod_id;
    }

    public void setProd_id(int prod_id) {
        this.prod_id = prod_id;
    }

    public String getProd_nombre() {
        return prod_nombre;
    }

    public void setProd_nombre(String prod_nombre) {
        this.prod_nombre = prod_nombre;
    }

    public String getProd_tipo() {
        return prod_tipo;
    }

    public void setProd_tipo(String prod_tipo) {
        this.prod_tipo = prod_tipo;
    }

    public String getProd_desc() {
        return prod_desc;
    }

    public void setProd_desc(String prod_desc) {
        this.prod_desc = prod_desc;
    }

    public int getStock_units() {
        return stock_units;
    }

    public void setStock_units(int stock_units) {
        this.stock_units = stock_units;
    }

    public float getStock_kg() {
        return stock_kg;
    }

    public void setStock_kg(float stock_kg) {
        this.stock_kg = stock_kg;
    }

    public float getPrecio_costo() {
        return precio_costo;
    }

    public void setPrecio_costo(float precio_costo) {
        this.precio_costo = precio_costo;
    }

    public int getSuc_id() {
        return suc_id;
    }

    public void setSuc_id(int suc_id) {
        this.suc_id = suc_id;
    }

    public String getFecha_ingreso() {
        return fecha_ingreso;
    }

    public void setFecha_ingreso(String fecha_ingreso) {
        this.fecha_ingreso = fecha_ingreso;
    }

    @Override
    public String toString() {
        return "Inventario [prod_id=" + prod_id + ", prod_nombre=" + prod_nombre + ", prod_tipo=" + prod_tipo
                + ", prod_desc=" + prod_desc + ", stock_units=" + stock_units + ", stock_kg=" + stock_kg
                + ", precio_costo=" + precio_costo + ", suc_id=" + suc_id + ", fecha_ingreso=" + fecha_ingreso + "]";
    }
}
