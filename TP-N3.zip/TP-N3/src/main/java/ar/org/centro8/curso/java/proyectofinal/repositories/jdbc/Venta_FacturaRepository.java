package ar.org.centro8.curso.java.proyectofinal.repositories.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.proyectofinal.entities.Venta_Factura;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_Venta_FacturaRepository;

public class Venta_FacturaRepository implements I_Venta_FacturaRepository {
    private Connection conn;

    public Venta_FacturaRepository(Connection conn) {
        this.conn = conn;
    }

    @Override
    public List<Venta_Factura> getAll() {
        List<Venta_Factura> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery(
                "select * from venta_facturas")) {
            while (rs.next()) {
                list.add(new Venta_Factura(
                        rs.getInt("ord_num"),
                        rs.getString("fecha_y_hora"),
                        rs.getString("medio_de_pago"),
                        rs.getFloat("precio_total")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    @Override
    public void save(Venta_Factura venta_factura) {
        if (venta_factura == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into venta_facturas (fecha_y_hora,ord_num,medio_de_pago,precio_total) values (?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
             ps.setInt(1, venta_factura.getOrd_num());
            ps.setString(2, venta_factura.getFecha_y_hora());
            ps.setString(3, venta_factura.getMedio_de_pago());
            ps.setFloat(4, venta_factura.getPrecio_total());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                venta_factura.setOrd_num(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }

    }

    @Override
    public void remove(Venta_Factura venta_factura) {
        if (venta_factura == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "delete from venta_facturas where ord_num=?")) {
            ps.setInt(1, venta_factura.getOrd_num());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }

    }

    @Override
    public void update(Venta_Factura venta_factura) {
        if (venta_factura == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "update venta_facturas set fecha_y_hora=?, medio_de_pago=?, precio_total=? where ord_num=?")) {
            ps.setString(1, venta_factura.getFecha_y_hora());
            ps.setString(2, venta_factura.getMedio_de_pago());
            ps.setFloat(3, venta_factura.getPrecio_total());
            ps.setInt(4, venta_factura.getOrd_num());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

}
