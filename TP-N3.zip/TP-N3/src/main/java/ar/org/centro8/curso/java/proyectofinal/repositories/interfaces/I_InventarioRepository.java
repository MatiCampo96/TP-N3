package ar.org.centro8.curso.java.proyectofinal.repositories.interfaces;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.proyectofinal.entities.Inventario;
import ar.org.centro8.curso.java.proyectofinal.entities.Sucursal;

public interface I_InventarioRepository {
    void save(Inventario inventario);
    void remove(Inventario inventario);
    void update(Inventario inventario);
    default Inventario getById(int prod_id){
        return getAll()
            .stream()
            .filter(a->a.getProd_id()==prod_id)
            .findAny()
            .orElse(new Inventario());        
    }
    List<Inventario>getAll();
    default List<Inventario>getLikeProd_nombre(String prod_nombre){
        if(prod_nombre==null) return new ArrayList();
        return getAll()
            .stream()
            .filter(a->a.getProd_nombre()!=null)
            .filter(a->a
                        .getProd_nombre()
                        .toLowerCase()
                        .contains(prod_nombre.toLowerCase()))
            .toList();
    }

    default List<Inventario>getLikeSucursal(Sucursal sucursal){
        if(sucursal==null) return new ArrayList();
        return getAll()
            .stream()
            .filter(a->a.getSuc_id()==sucursal.getSuc_id())
            .toList();
    }
}
