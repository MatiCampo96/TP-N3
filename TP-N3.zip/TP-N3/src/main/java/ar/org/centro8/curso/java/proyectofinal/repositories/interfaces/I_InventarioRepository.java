package ar.org.centro8.curso.java.proyectofinal.repositories.interfaces;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import ar.org.centro8.curso.java.proyectofinal.entities.Inventario;
import ar.org.centro8.curso.java.proyectofinal.entities.Sucursal;

public interface I_InventarioRepository {
    void save(Inventario inventario);
    void remove(Inventario inventario);
    void update(Inventario inventario);

    List<Inventario>getAll();

    default Stream<Inventario> getStream(){
        return getAll().stream();
    }

    default Inventario getById(int prod_id){
        return getAll()
            .stream()
            .filter(a->a.getProd_id()==prod_id)
            .findAny()
            .orElse(new Inventario());        
    }
    default List<Inventario>getLikeProd_nombre(String prod_nombre){
        if(prod_nombre==null) return new ArrayList();
        return getAll()
            .stream()
            .filter(a->a.getProd_nombre()!=null)
            .filter(a->a
                        .getProd_nombre()
                        .toLowerCase()
                        .contains(prod_nombre.toLowerCase()))
            .toList();
    }

    default List<Inventario>getBySucursal(Sucursal sucursal){
        if(sucursal==null) return new ArrayList<Inventario>();
        return getStream()
            .filter(a->a.getSuc_id()==sucursal.getSuc_id())
            .collect(Collectors.toList());
    }

   default List<Inventario>getLikeProd_tipo(String prod_tipo){
    if(prod_tipo==null) return new ArrayList();
    return getAll()
        .stream()
        .filter(a->a.getProd_tipo()!=null)
        .filter(a->a
                    .getProd_tipo()
                    .toLowerCase()
                    .contains(prod_tipo.toLowerCase()))
        .toList();
}
  default List<Inventario>getLikeProd_desc(String prod_desc){
    if(prod_desc==null) return new ArrayList();
    return getAll()
        .stream()
        .filter(a->a.getProd_desc()!=null)
        .filter(a->a
                    .getProd_desc()
                    .toLowerCase()
                    .contains(prod_desc.toLowerCase()))
        .toList();
}
 //   probar private int stock_units; TODO!
 default List<Inventario>getStock_units(int stock_units){
    if(stock_units==0) return new ArrayList();
    return getAll()
        .stream()
        .filter(a->a.getStock_units()!=0)
        .toList();
}
 //   private float stock_kg; TODO!
  //  private float precio_costo; TODO!

 default List<Inventario>getLikeFecha_ingreso(String fecha_ingreso){
    if(fecha_ingreso==null) return new ArrayList();
    return getAll()
        .stream()
        .filter(a->a.getFecha_ingreso()!=null)
        .filter(a->a
                    .getFecha_ingreso()
                    .toLowerCase()
                    .contains(fecha_ingreso.toLowerCase()))
        .toList();
}
}

