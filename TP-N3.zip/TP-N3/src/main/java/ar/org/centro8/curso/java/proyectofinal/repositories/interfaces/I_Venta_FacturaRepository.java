package ar.org.centro8.curso.java.proyectofinal.repositories.interfaces;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.proyectofinal.entities.Venta_Factura;

public interface I_Venta_FacturaRepository {
    void save(Venta_Factura venta_factura);
    void remove(Venta_Factura venta_factura);
    void update(Venta_Factura venta_factura);
    default Venta_Factura getById(int ord_num){
        return getAll()
            .stream()
            .filter(a->a.getOrd_num()==ord_num)
            .findAny()
            .orElse(new Venta_Factura());        
    }
    List<Venta_Factura>getAll();
}
