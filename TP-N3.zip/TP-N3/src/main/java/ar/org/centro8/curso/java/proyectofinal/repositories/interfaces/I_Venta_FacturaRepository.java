package ar.org.centro8.curso.java.proyectofinal.repositories.interfaces;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import ar.org.centro8.curso.java.proyectofinal.entities.Venta_Factura;

public interface I_Venta_FacturaRepository {
    void save(Venta_Factura venta_factura);
    void remove(Venta_Factura venta_factura);
    void update(Venta_Factura venta_factura);

    List<Venta_Factura>getAll();

    default Stream<Venta_Factura> getStream(){
        return getAll().stream();
    }
    default Venta_Factura getById(int ord_num){
        return getAll()
            .stream()
            .filter(a->a.getOrd_num()==ord_num)
            .findAny()
            .orElse(new Venta_Factura());        
    }
    //Fecha y hora TODO!
    default List<Venta_Factura>getLikeFecha_y_hora(String fecha_y_hora){
        if(fecha_y_hora==null) return new ArrayList();
        return getAll()
            .stream()
            .filter(a->a.getFecha_y_hora()!=null)
            .filter(a->a
                        .getFecha_y_hora()
                        .toLowerCase()
                        .contains(fecha_y_hora.toLowerCase()))
            .toList();
    }
    
    default List<Venta_Factura>getLikeSuc_nombre(String medio_de_pago){
        if(medio_de_pago==null) return new ArrayList();
        return getAll()
            .stream()
            .filter(a->a.getMedio_de_pago()!=null)
            .filter(a->a
                        .getMedio_de_pago()
                        .toLowerCase()
                        .contains(medio_de_pago.toLowerCase()))
            .toList();
    }
/*     //precio_total comentado por ser float REVISAR TODO!
default Venta_Factura getByPrecio_total(float precio_total){
    return getAll()
        .stream()
        .filter(a->a.getPrecio_total()==precio_total)
        .findAny()
        .orElse(new Venta_Factura());        
} */
}



