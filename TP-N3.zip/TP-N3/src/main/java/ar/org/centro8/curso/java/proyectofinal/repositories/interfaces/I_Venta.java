package ar.org.centro8.curso.java.proyectofinal.repositories.interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import ar.org.centro8.curso.java.proyectofinal.entities.Venta;
import ar.org.centro8.curso.java.proyectofinal.entities.Inventario;
import ar.org.centro8.curso.java.proyectofinal.entities.Venta_Factura;

public interface I_Venta {
    void save(Venta venta);

    void remove(Venta venta);

    void update(Venta venta);

    List<Venta_Factura> getAll();

    default Stream<Venta> getStream(){
        return getAll().stream();
    }
    default Venta getByOrd_numAndProd_id(int ord_num, int prod_id){
        return getAll()
            .stream()
            .filter(a->a.getOrd_num()==ord_num)
            .filter(a->a.getProd_id()==prod_id)
            .findAny()
            .orElse(new Venta());        
    }
    default Venta_Factura getById(int ord_num){
        return getAll()
            .stream()
            .filter(a->a.getOrd_num()==ord_num)
            .findAny()
            .orElse(new Venta_Factura());        
    }


}
/*    private int ord_num;
    private int prod_id;
    private String prod_sabor;
    private String prod_presentacion;
    private float cant_peso;
    private int cant_units;
    private float precio_unitario; */