package ar.org.centro8.curso.java.proyectofinal.repositories.interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import ar.org.centro8.curso.java.proyectofinal.entities.Venta;
import ar.org.centro8.curso.java.proyectofinal.entities.Inventario;
import ar.org.centro8.curso.java.proyectofinal.entities.Venta_Factura;

public interface I_Venta {
    void save(Venta venta);

    void remove(Venta venta);

    void update(Venta venta);

    List<Venta> getAll();

    default Stream<Venta> getStream() {
        return getAll().stream();
    }

    default Venta getById(int ord_num, int prod_id) {
        return getAll()
                .stream()
                .filter(a -> a.getOrd_num() == ord_num && a.getProd_id() == prod_id)
                .findAny()
                .orElse(new Venta());
    }

//   private int ord_num;
//  * private int prod_id;
//  * private String prod_sabor;

default List<Venta>getLikeProd_sabor(String prod_sabor){
    if(prod_sabor==null) return new ArrayList();
    return getAll()
        .stream()
        .filter(a->a.getProd_sabor()!=null)
        .filter(a->a
                    .getProd_sabor()
                    .toLowerCase()
                    .contains(prod_sabor.toLowerCase()))
        .toList();
}

default List<Venta>getLikeProd_presentacion(String prod_presentacion){
    if(prod_presentacion==null) return new ArrayList();
    return getAll()
        .stream()
        .filter(a->a.getProd_presentacion()!=null)
        .filter(a->a
                    .getProd_presentacion()
                    .toLowerCase()
                    .contains(prod_presentacion.toLowerCase()))
        .toList();
}

//Probar TODO!
default List<Venta>getCant_units(int cant_units){
    if(cant_units==0) return new ArrayList();
    return getAll()
        .stream()
        .filter(a->a.getCant_units()!=0)
        .toList();
}
}
//  * private float precio_unitario;
//  * private float cant_peso;
//  * private int cant_units;
 