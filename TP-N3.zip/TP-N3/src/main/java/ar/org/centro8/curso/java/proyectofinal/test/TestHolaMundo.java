package ar.org.centro8.curso.java.proyectofinal.test;

public class TestHolaMundo {
    public static void main(String[] args) {
        System.out.println("Hola Mundo!!");
        empleadoRepository.getAll().forEach(System.out::println);
    }
}
