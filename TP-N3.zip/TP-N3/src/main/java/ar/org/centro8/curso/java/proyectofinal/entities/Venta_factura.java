package ar.org.centro8.curso.java.proyectofinal.entities;

public class Venta_factura {
    
}
