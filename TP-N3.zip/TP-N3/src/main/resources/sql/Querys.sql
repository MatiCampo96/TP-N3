-- Querys

-- Mostrar ordenes de venta en la sucursal de moron

SELECT DISTINCT
    fecha_y_hora,
    vf.ord_num,
    medio_de_pago,
    precio_total,
    s.ciudad
FROM
    venta_facturas vf
        INNER JOIN
    ventas v ON v.ord_num = vf.ord_num
        INNER JOIN
    inventario i ON v.prod_id = i.prod_id
        INNER JOIN
    sucursales s ON i.suc_id = s.suc_id
WHERE
    s.ciudad = 'Moron';

-- Empleado con mayor antigüedad en la sucursal de Haedo.

SELECT 
    CONCAT(nombre, ' ', apellido) Empleado,
    MIN(fecha_contratacion) 'Fecha de contratación'
FROM
    empleados e
        INNER JOIN
    sucursales s ON e.suc_id = s.suc_id
WHERE
    fecha_contratacion = (SELECT 
            MIN(fecha_contratacion)
        FROM
            empleados e
                INNER JOIN
            sucursales s ON e.suc_id = s.suc_id
        WHERE
            s.ciudad = 'Haedo');


-- Mostrar total de ganancias recaudadas en cada sucusal en orden descendente: 

SELECT 
    SUM(DISTINCT precio_total) ganancias, s.suc_nombre, s.suc_id
FROM
    venta_facturas vf
        INNER JOIN
    ventas v ON v.ord_num = vf.ord_num
        INNER JOIN
    inventario i ON v.prod_id = i.prod_id
        INNER JOIN
    sucursales s ON i.suc_id = s.suc_id
GROUP BY s.suc_id
ORDER BY ganancias DESC;


-- Cantidad total de helado de frutilla que ingreso en todas las sucursales.

SELECT 
    SUM(stock_kg) 'Cantidad total de helado de frutilla en kilos'
FROM
    inventario
WHERE
    prod_nombre = 'helado de frutilla';


-- Mostrar la/las sucursales que no hayan hecho ninguna venta

SELECT 
    suc_nombre AS sucursal, v.ord_num
FROM
    sucursales s
        INNER JOIN
    inventario i ON s.suc_id = i.suc_id
        LEFT JOIN
    ventas v ON i.prod_id = v.prod_id
GROUP BY s.suc_id
HAVING ord_num IS NULL;