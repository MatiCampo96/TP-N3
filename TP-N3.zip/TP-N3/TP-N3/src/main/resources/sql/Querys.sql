-- Querys

-- Ordenes de ventas realizadas en la sucursal de Moron.

select distinct
fecha_y_hora, vf.ord_num, 
medio_de_pago, precio_total, s.ciudad
from venta_facturas vf
inner join ventas v
on v.ord_num=vf.ord_num
inner join inventario i
on v.prod_id=i.prod_id
inner join sucursales s
on i.suc_id=s.suc_id
where s.ciudad="Moron";

-- Empleado con mayor antigüedad en la sucursal de Haedo.

select 
concat(nombre,' ',apellido) Empleado,
min(fecha_contratacion) 'Fecha de contratación'
from empleados e
inner join sucursales s
on e.suc_id=s.suc_id
where
fecha_contratacion=(select min(fecha_contratacion) from empleados e inner join sucursales s on e.suc_id=s.suc_id where s.ciudad="Haedo");

-- Sucursal con mas dinero recaudado: 
select distinct
max(precio_total) TOTAL,
s.suc_nombre, s.suc_id, vf.ord_num
from venta_facturas vf
inner join ventas v
on v.ord_num=vf.ord_num
inner join inventario i
on v.prod_id=i.prod_id
inner join sucursales s
on i.suc_id=s.suc_id
where vf.TOTAL=
(select sum(precio_total) from venta_facturas vf
inner join ventas v
on v.ord_num=vf.ord_num
inner join inventario i
on v.prod_id=i.prod_id
inner join sucursales s
on i.suc_id=s.suc_id
group by s.suc_id)
;


select distinct
precio_total,
s.suc_nombre, s.suc_id
from venta_facturas vf
inner join ventas v
on v.ord_num=vf.ord_num
inner join inventario i
on v.prod_id=i.prod_id
inner join sucursales s
on i.suc_id=s.suc_id
;