use heladeria_el_frio;

describe sucursales;
insert into sucursales values
	(1,'El frio Moron','Av. Rivadavia 14500','Moron'),
	(2,'El frio Haedo','Av. Allem 284','Haedo'),
	(3,'El frio Velez','Av. Gaona 4256','Velez'),
	(4,'El frio Colegiales','Pastor Obligado 1287','Colegiales');
select * from sucursales;

describe empleados;
insert into empleados values
	(1,'Ernesto', 'Morales', 3, 'encargado', 70000, '2018-10-25'),
	(2,'Mariana','Lemos',2, 'cadete', 50000, '2020-5-29'),
	(3,'Lucas','Mendez', 3,'cadete', 50000, '2021-4-12'),
	(4,'Hanna','Olivera', 2,'encargado', 70000, '2019-7-04'),
    (6,'Mariano', 'Ocampos', 1, 'encargado', 70000, '2019-4-09'),
	(7,'Mabel','Juanes',4, 'cadete', 50000, '2021-08-18'),
	(8,'Martin','Gonzales', 1,'cadete', 50000, '2020-06-14'),
	(9,'Julieta','Gafoz', 4,'encargado', 70000, '2018-05-25'),
    (10,'Marcos', 'Ramirez', 1, 'aprendiz', 38000, '2022-09-29'),
	(11,'Sofia','Carrasco',2, 'cadete', 50000, '2021-09-21'),
	(12,'Marcelo','Montiel', 3,'cadete', 50000, '2020-05-15'),
	(13,'Soledad','Kowals', 4,'aprendiz', 38000, '2022-10-01');
select* from empleados;

 describe inventario;
insert into inventario values
(1,'helado de frutilla', 'sabor','Helado artesanal sabor frutilla con pulpa de frutilla, contiene TAC.',null, 20, 1200, 1,"2022-02-02"),
(2, 'helado de vainilla', 'sabor','Helado artesanal sabor frutilla, contiene TAC.', null, 20, 1200, 1,"2022-02-02"),
(3, 'helado de chocolate', 'sabor','Helado artesanal sabor chocolate con chocolate en trozos, contiene TAC.',null, 20, 1200, 1,"2022-02-02"),
(4, 'cono de 2 bochas', 'presentacion','Cono comestible para servir con 2 bochas de helado.', 200, null, 400, 1,"2022-01-01"),
(5, 'pote 1/2kg', 'presentacion','Recipiente de tergopol para envasar 1/2kg de helado, para consumir en el lugar o llevar.', 50, null, 800, 1,"2022-01-01"),
(6, 'pote 1kg', 'presentacion','Recipiente de tergopol para envasar 1kg de helado, para consumir en el lugar o llevar.', 50, null, 1200, 1,"2022-01-01"),
(7,'helado de frutilla', 'sabor','Helado artesanal sabor frutilla con pulpa de frutilla, contiene TAC.', null, 10, 1200, 2,"2022-04-01"),
(8, 'helado de vainilla', 'sabor','Helado artesanal sabor vainilla, contiene TAC.', null, 20, 1200, 2,"2022-04-01"),
(9, 'helado de chocolate', 'sabor','Helado artesanal sabor chocolate con trozos de chocolate, contiene TAC.', null, 30, 1200, 2,"2022-04-01"),
(10, 'cono de 2 bochas', 'presentacion','Cono comestible para servir con 2 bochas de helado.', 220, null, 400, 2,"2022-04-01"),
(11, 'pote 1/2kg', 'presentacion','Recipiente de tergopol para envasar 1/2kg de helado, para consumir en el lugar o llevar.', 40, null, 800, 2,"2022-04-01"),
(12, 'pote 1kg', 'presentacion','Recipiente de tergopol para envasar 1kg de helado, para consumir en el lugar o llevar.', 59, null, 1200, 2,"2022-04-01"),
(13, 'helado de vainilla', 'sabor','Helado artesanal sabor vainilla, contiene TAC.', null, 20, 1200, 3,"2022-05-01"),
(14, 'helado de chocolate', 'sabor', 'Helado artesanal sabor chocolate con trozos de chocolate, contiene TAC.', null, 20, 1200, 3,"2022-05-01"),
(15, 'cono de 2 bochas', 'presentacion', 'Cono comestible para servir con 2 bochas de helado.', 20, null, 400, 3,"2022-05-01"),
(16, 'pote 1/2kg', 'presentacion','Recipiente de tergopol para envasar 1/2kg de helado, para consumir en el lugar o llevar.', 50, null, 800, 3,"2022-05-01"),
(17, 'pote 1kg', 'presentacion','Recipiente de tergopol para envasar 1kg de helado, para consumir en el lugar o llevar.', 5, null, 1200, 3,"2022-05-01"),
(18,'helado de frutilla', 'sabor', 'Helado artesanal sabor frutilla con pulpa de frutilla, contiene TAC.', null, 20, 1200, 4,"2022-07-15"),
(19, 'helado de vainilla', 'sabor', 'Helado artesanal sabor vainilla, contiene TAC.', null, 60, 1200, 4,"2022-07-15"),
(20, 'cono de 2 bochas', 'presentacion', 'Cono comestible para servir con 2 bochas de helado.', 100, null, 400, 4,"2022-07-15"),
(21, 'pote 1/2kg', 'presentacion','Recipiente de tergopol para envasar 1/2kg de helado, para consumir en el lugar o llevar.', 50, null, 800, 4,"2022-07-15"),
(22, 'pote 1kg', 'presentacion','Recipiente de tergopol para envasar 1kg de helado, para consumir en el lugar o llevar.', 80, null, 1200, 4,"2022-07-15");
 select* from inventario;
 
 describe venta_facturas;
 insert into venta_facturas values
 ("2022-10-11 17:10:16", 1, "efectivo", 400),
 ("2022-10-10 18:46:24", 2, "debito",  1000),
 ("2022-10-10 14:26:23", 3, "credito", 1980),
 ("2022-10-12 19:23:12", 4, "mercadopago", 400),
 ("2022-10-12 12:45:32", 5, "efectivo", 1800);
 select* from venta_facturas;
 
 describe ventas;
 insert into ventas values
 (1, 1, "frutilla", null ,0.100 ,null, null), 
 (1, 2, "vainilla", null ,0.100 ,null, null),
 (1, 4, null, "cono de 2 bochas", null, 1, 400),
 (2, 13, "vainilla", null, 0.500, null, null),
 (2, 16, null, "pote de 1/2kg", null, 1, 1000),
 (3, 18, "frutilla", null, 0.333, null, null),
 (3, 19, "vainilla", null, 0.667, null, null),
 (3, 22, null, "pote de 1kg", null, 1, 1800),
 (4, 13, "vainilla", null, 0.200, null, null),
 (4, 15, null, "cono de 2 bochas", null, 1, 400),
 (5, 14, "chocolate", null, 1.00, null, null),
 (5, 17, null, "pote de 1kg", null, 1, 1800);
 select*from ventas;